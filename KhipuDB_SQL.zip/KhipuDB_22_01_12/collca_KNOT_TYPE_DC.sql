CREATE DATABASE  IF NOT EXISTS `collca` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `collca`;
-- MySQL dump 10.13  Distrib 5.5.9, for Win32 (x86)
--
-- Host: khipukamayuq.fas.harvard.edu    Database: collca
-- ------------------------------------------------------
-- Server version	5.5.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `KNOT_TYPE_DC`
--

DROP TABLE IF EXISTS `KNOT_TYPE_DC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KNOT_TYPE_DC` (
  `TYPE_CODE` varchar(3) DEFAULT NULL,
  `TYPE_DESCR` varchar(100) DEFAULT NULL,
  `NOTES` varchar(1000) DEFAULT NULL,
  `CODE_ORDER` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KNOT_TYPE_DC`
--

LOCK TABLES `KNOT_TYPE_DC` WRITE;
/*!40000 ALTER TABLE `KNOT_TYPE_DC` DISABLE KEYS */;
INSERT INTO `KNOT_TYPE_DC` VALUES ('L','long','',1),('E','figure eight','',2),('S','single','',3),('EE','double figure 8','',4),('LL','double long ','found in Dahlsberg khipu; appears something like a long knot with two axes.  Aschers give it a value of 3.',5),('BL','belted long knot','found on UR035; long knot with an extra wrap around the outside',6),('SP','Spiral Knot','Value like a long knot',7),('TF','turfted knot','value = 1',8);
/*!40000 ALTER TABLE `KNOT_TYPE_DC` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-01-22 20:00:44
