Khipu Database

last upload: Jan 22, 2012


========================================

Schema Description:

The khipu data is contained in the following tables 
(see also: http://khipukamayuq.fas.harvard.edu/ProjectDescrERD.html)

---------------
Primary data
---------------

KHIPU_MAIN, PRIMARY_CORD: contain khipu-level information and details
of the "primary" cord to which pendants are attached. The number of 
entries is the same except a duplicate entry in Khipu_main for UR167
due to uncertainty of the provenance from which the khipu came.

PRIMARY_CORD_ATTACH: describes primary cords that are tied to each other,
such as Ascher khipu #35 from Brooklyn museum that contains parts A,B,C and D
each recorded in the DB as a separate Khipu/Primary cord

CORD_CLUSTER: contains information on how pentant cords are grouped 
(clustered) on the primary cord. In original version of Khipu tabulation
app subsidiary cords were recognized as separate clusters, but this has 
been deprecated in the latest version. The relevant information on each
individual subsidiary cord's position along its parent cord is instead
recorded in the propery ATTACH_POSITION of the CORD table.

CORD: contains information about individual cords, including length, fiber,
attachment type, spin/ply, but excluding color information.

ASCHER_CORD_COLOR: contains color information of primary and subsidiary cords
(all entries in PRIMARY_CORD and CORD tables). Since some cords contain 
sections of different color (e.g. from 0-20cm cord is white from 20 cm - end 
it's brown), the number of entries in ASCHER_CORD_COLOR exceeds the total
number of cords recorded in PRIMARY_CORD and CORD tables. In addition5 to these
color ranges, a cord might be composed of multicolor threads (up to 5 different
color threads). Relationship between this threads is described by COLOR_OPERATOR
property, such as mottled, barber pole or con elementaro.

KNOT_CLUSTER: contains information about knot clusters on a cord, such as position
and number of knots.

KNOT: contains the values of actual knots found on a given cluster of a given cord,
as well as knot type and it's axis orientation.


---------------
Additional data
---------------

ASCHER_CANUTO_COLOR, ASCHER_CANUTITO_COLOR, CANUTITO, CANUTO, CANUTO_CLUSTER,
CANUTO_CORD_FLAT, X_CANUTO_CORD_FLAT: contain information on pre-Inca khipus
on whic records were made without decimal knot system of the Inca empire.


---------------
Descriptors
---------------

*_DC (everything ending in DC): tables that contain explanations and additional 
information on the abbreviations used throughout the database that describe
color types	, knot types, termination types, etc.

